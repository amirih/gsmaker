#!/usr/bin/env bash

# Replace the main class with your own
java -cp classes/:lib/* RunTests
